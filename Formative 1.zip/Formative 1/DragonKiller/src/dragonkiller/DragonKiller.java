/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dragonkiller;
import java.util.*;
/**
 *
 * @author user
 */
public class DragonKiller {

    /**
     * @param arg the command line arguments
     */
    public static void main(String[] arg) {
    //asking the user to enter their name and surname
    String text;
    int countWords=0;
         
    Scanner sc=new Scanner(System.in);
         
    System.out.print("Enter name and surname: ");
    
    text = sc.nextLine();
    
    
    
    
    //counting charactors of the name and surname    
    for(int i=0; i<text.length(); i++)
    {
     if(text.charAt(i)==' ' && text.charAt(i+1)!=' ')
            countWords++   ;
    }
     System.out.println("Total number of words in string are: "+ (countWords+1));  
     System.out.println("random numbers");  
    
    
     
     
    //using the loops and randomly counting the total of characters between 10 and 50 
    Random rd = new Random(); 
    int[] array = new int[10];
    int temp;
    for (int i = 0; i < array.length; i++) {
        array[i] = rd.nextInt();
        {
            System.out.println(array[i]);
            
        }
       
        
        
        //sorting and making a temporary number for looping
        for (int x = 1; x < array.length; x++) {
    for (int j = x; j > 0; j--) {
        if (array[j] < array [j - 1]) {
            temp = array[j];
            array[j] = array[j - 1];
            array[j - 1] = temp;
            break;
            
            }
        for (int y = x+1; y < array.length; y++) {
        System.out.println(array[y]);
    } 
        }
    }
    
    }
    
   
   }
    }
    


