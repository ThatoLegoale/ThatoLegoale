﻿using System;

namespace TestSearchReplace
{
    // A class added as instructed.
    class SearchReplace
    {
        string Sentence;
        string searchstr;
        string replace;

        public string SearchSubString()
        {
            string Sentence = "";
            return Sentence;


        }

        void ReplaceSubString()
        {
            string replace = "result";
            Console.WriteLine(replace);
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
          
            
            
            // Object called
            SearchReplace SR = new SearchReplace();
            Console.WriteLine("Enter Your Sentance or Any String:");


            // a string that reprsents entering a string
            string Sentence = Console.ReadLine();


            //Print out what the user has enterd.
            Console.WriteLine("Your Name is or the String you entered is:" + Sentence);


            // Asking the user to enter a string they typed before to search for it.
            Console.WriteLine("Enter a substring you want to search:");

            //A method to search for a string and if the string is wrong you never enterd that string it will print the code after else
            string searchstr = Console.ReadLine();
            int index = Sentence.IndexOf(searchstr);
            if (index < 0)
            {
                Console.WriteLine("The subString you are looking for its not found..");
            }
            else
            {
                Console.WriteLine("This what you are looking for '{0}' in '{1}' ", searchstr, Sentence, index);
            }

            // Entering the string that the user would like to replace a substring with
            Console.WriteLine("Enert a new String you would like to replace a substring");

            string replace = Console.ReadLine();
            // Making use of printing out a new substring
            Console.WriteLine("Your new string is:" + SR.SearchSubString());
            
            Console.ReadLine();
        }
    }
}

