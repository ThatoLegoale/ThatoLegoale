﻿using System;

namespace TestEmployee
{
    class Employee
    {
        // instance variables
        string Fname;
        int hourRate;
        int workHours;
        double netPay;
        double grossPay;


        // Default constructor
        public Employee()
        {

        }

        // Constructor that initialize the instance variables
        public Employee(string Fname, int hourRate, int workHours, double netPay, double grossPay)
        {
            this.Fname = Fname;
            this.hourRate = hourRate;
            this.workHours = workHours;
            this.netPay = netPay;
            this.grossPay = grossPay;
        }
        public void setFname()
        {
            Fname = "variable";
        }

        // Making use of set and get methods wiyh all variables initialized
        public string getFname()
        {
            return Fname;
        }

        public void sethourRate()
        {
            hourRate = 0;
        }

        public int gethourRate()
        {
            return hourRate;
        }

        public void setworkHours()
        {
            workHours = 0;
        }

        public int getworkHours()
        {
            return workHours;
        }

        public void setnetPay()
        {
            netPay = .00;
        }

        public double getnetPay()
        {
            return netPay;
        }

        public void setgrossPay()
        {
            grossPay = .00;
        }

        public double getgrossPay()
        {
            return grossPay;
        }

        public void calculatorPay(double grossPay, double netPay)
        {
            double gross = (workHours * hourRate * 1.5);
            Console.WriteLine(gross);

            double net = (gross - workHours * hourRate * 1.5);
            Console.WriteLine(net);

        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            Employee Emp = new Employee();

            // Employee to enter their name and it prints it back
            Console.WriteLine("Emlpoyee Enter your name");
            string Fname = Console.ReadLine();
            Console.WriteLine("Your name is.:" + Fname + Emp.getFname());

            //Employee to enter their pay rate per working hours
            Console.WriteLine("Enter your pay rate per hour ");
            string Rate = Console.ReadLine();

            // converting a string to an integer
            int hourRate = Convert.ToInt32(Rate);
            Console.WriteLine("Your payment rate per hour is:" + "R" + Rate + Emp.gethourRate());

            Console.WriteLine("Enter a number of hours you worked this Month :");
            string Hours = Console.ReadLine();

            // Converting a string to a double
            int workHours = Convert.ToInt32(Hours);
            Console.WriteLine("Your Working hours for this Month is.." + Hours + " "+ "Hours" + Emp.getworkHours());


            // Display the grosspayment method on calculating it
            double gross = (workHours * hourRate * 1.5);
            Console.WriteLine("Your GrossPayment is:" + "R" + gross + " " + Emp.getgrossPay());


            // Displaying the netpayment method by calculating it and an extra R for profession 
            double net = (gross / 1.5);
            Console.WriteLine("Your Net Payment is:" + "R" + net + Emp.getnetPay());

            if (gross < 5000)
            {
                Console.WriteLine("Your work is good");
            }
            else
            {
                Console.WriteLine("Error Press Stop or Alt to return" + Emp.getFname());
            }

            Console.ReadLine();

        }
        
    }
}
