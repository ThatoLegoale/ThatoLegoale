﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Form2 
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        int contacts;
        private object listbox1;
        string[] contact = System.IO.File.ReadAllLines(@"Contacts.Text");// Notepad created
        private string winDir;


        // initiolising the objects by first setting them and getting them
        public object TextBox3 { get; private set; }
        public object TextBox1 { get; private set; }
        public object TextBox2 { get; private set; }

        public MainWindow()
        {
            InitializeComponent();
            Add();
        }

        // Method of adding values inside a list box
        private void Add()
        {
            for (int i = 0; i < contact.Length; i++)
            {
                listBox1.Items.Add(contact[i]);// Error trying to add values and by also counting them
                contacts++;
            }
        }

        // Search button method
        private void Btn_Search_Click(object sender, RoutedEventArgs e)
        {
            string file_name = "\\new contact.txt";
            file_name = Environment.GetFolderPath(Environment.SpecialFolder.Desktop) + file_name;

        }

        private class listBox1
        {
            public static object Items { get; internal set; }
        }


        // Wanted to link the text file but it is giving me errors
        private void ListBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            this.listBox1.Items.Clear();
            StreamReader reader = new StreamReader(winDir + "\\system.ini");
            try
            {
                do
                {
                    addListItem(reader.ReadLine());
                }
                while (reader.Peek() != -1);
            }
            catch
            {
                addListItem("File is empty");
            }
            finally
            {
                reader.Close();
            }
        }

        private void addListItem(string v)
        {
            throw new NotImplementedException();
        }
    }
}
