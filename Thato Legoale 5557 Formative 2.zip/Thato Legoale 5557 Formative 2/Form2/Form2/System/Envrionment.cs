﻿namespace System
{
    internal class Envrionment
    {
        public static object CurrentDirectory { get; internal set; }
    }
}