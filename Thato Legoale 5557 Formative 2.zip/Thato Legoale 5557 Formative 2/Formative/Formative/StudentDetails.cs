﻿namespace Formative
{
    internal class StudentDetails
    {
    }
}