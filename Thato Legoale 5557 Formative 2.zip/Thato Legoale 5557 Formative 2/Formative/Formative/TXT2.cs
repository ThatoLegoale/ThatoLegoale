﻿namespace Formative
{
    internal class TXT2
    {
        public static string Text { get; internal set; }
    }
}