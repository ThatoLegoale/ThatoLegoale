﻿namespace Formative
{
    internal class StudentInformationEntities
    {
        public StudentInformationEntities()
        {
        }
    }
}