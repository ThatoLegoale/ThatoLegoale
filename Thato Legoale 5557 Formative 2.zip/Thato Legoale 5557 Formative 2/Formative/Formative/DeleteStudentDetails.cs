﻿namespace Formative
{
    internal class DeleteStudentDetails
    {
    }
}