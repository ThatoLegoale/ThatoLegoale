﻿using System;
using System.Windows.Forms;

namespace Formative
{
    internal class BindingSource_bs
    {
        public object DataSource { get; internal set; }

        public static implicit operator BindingSource_bs(BindingSource v)
        {
            throw new NotImplementedException();
        }
    }
}