﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace Formative
{
    internal class DataGridViewChexkBoxColumn
    {
        public string HeaderText { get; internal set; }
        public Type ValueType { get; internal set; }
        public string Name { get; internal set; }
    }

    class dataGridView1
    {
        internal static IEnumerable<DataGridViewRow> SelectedRows;

        public static IEnumerable<DataGridViewRow> Rows { get; internal set; }
    }
}