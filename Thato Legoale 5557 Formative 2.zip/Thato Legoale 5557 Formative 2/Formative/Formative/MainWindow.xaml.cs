﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Windows;
using System.Text;
using System.Windows.Controls;
using System.Windows.Forms;
using System.Xaml;
using System.Drawing;
using System.Collections;
using System.ComponentModel;


namespace Formative
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private string sqlconnect;
        private DataTable dataGridView1;
        private object connection;


        public MainWindow()
        {

            InitializeComponent();

            // Connection of database linking a database 
            string connectionString = "SERVER = localhost; DATABASE = Formative; UID=root;Password=;";
            SqlConnection connection = new SqlConnection(connectionString);
            SqlCommand command = new SqlCommand("Select * from [dbo].[StudentInfo]", connection);
            connection.Open();
            DataTable dt = new DataTable();
            dt.Load(command.ExecuteReader());
            connection.Close();

            dtGrid.DataContext = dt;

        }
        private void Btn_Create_Click(object sender, RoutedEventArgs e)
        {
            SqlConnection sqlconnect = new SqlConnection(connectionString:);

            // creating a form button has given me a lot of errors

            try
            {
                string query = "Insert data INTO [dbo].[StudentInfo](ID, Name@Name, Surname@Surname, MI@MI, Gender@Gender, Address@Address, Birthday@Birthday";
                sqlconnect.Open();
                SqlCommand comd = new SqlCommand(query, sqlconnect,);

                //Called an object of a Parameter thinking that it will fix some errors
                SqlParameter para = new SqlParameter();

                SqlCommand.para.AddValue("@ID, TXT1_studID.Text");
                SqlCommand.para.AddValue("@Name, TXT2_Name.Text");
                SqlCommand.para.AddValue("@Surname, TXT3_Surname.Text");
                SqlCommand.para.AddValue("@MI, TXT4_MI.Text");
                SqlCommand.para.AddValue("@Gender, TXT5_Gender.Text");
                SqlCommand.para.AddValue("@Address, TXT6_Address.Text");
                SqlCommand.para.AddValue("@Birthday, TXT7_Birthday.Text");

                SqlDataReader dr = ExecuteReader();
                sqlconnect.Close();
            }
            catch (Exception a)
            {
                Message.Show(a.Message);
            }
        }

        private SqlDataReader ExecuteReader()
        {
            throw new NotImplementedException();
        }

        public SqlCommand query { get; private set; }
        public object TXT1_studID { get; private set; }


        // Button method of updating data into a database
        private void Btn_Update_Click(object sender, RoutedEventArgs e)
        {
            // First linking again
            string connectionString = "SERVER = localhost; DATABASE = Formative; UID=root;Password=;";
            SqlConnection connection = new SqlConnection(connectionString);
            SqlDataAdapter adp = new SqlDataAdapter(query, sqlconnect);
            connection.Open();
            SqlCommand command = new SqlCommand("Select * from[dbo].[StudentInfo] where ID=", connection);
            DataTable dt = new DataTable();

            adp.Fill(dt);
            dataGridView1 = dt;
            connection.Close();
        }


        // method of a read button provides user to display data they enterd
        private void Btn_Read_CLick(object sender, RoutedEventArgs e)
        {
            display();

        }

        private void display()
        {
            throw new NotImplementedException();
        }

        public void display(string query)
        {
            SqlConnection connection = new SqlConnection();
            SqlDataAdapter sqlAdapter = new SqlDataAdapter("Select * from [dbo].[StudentInfo Where Formative", connection);

            connection.Open();
            DataTable dt = new DataTable();
            sqlAdapter.Fill(dt);
            dataGridView1 = dt;
            connection.Close();
        }

        private object GetData(string query, SqlConnection connection)
        {
            throw new NotImplementedException();
        }

        // Method of a search button
        private void Btn_Search_Click(object sender, RoutedEventArgs e)
        {
            SqlConnection sqlconnect = new SqlConnection(connectionString:);
            try
            {
                sqlconnect.Open();
                string query = "Selecte * from [dbo].[StudentInfo Where ID =" + int.Parse(TXT1_studID.Text);
                SqlCommand comd = new SqlCommand(query, sqlconnect);
                display(query, sqlconnect);

            }
            catch (Exception a)
            {
                System.Windows.MessageBox.Show(a.Message);
            }
        }

        private void display(string query, SqlConnection sqlconnect)
        {
            throw new NotImplementedException();
        }

        // method of deleting data into a linked database
        private void Btn_Delete_Click(object sender, RoutedEventArgs e)
        {
            SqlConnection sqlconnect = new SqlConnection(connectionString:);// SQL linking connection
            try
            {
                sqlconnect.Open();
                string query = "Selecte * from [dbo].[StudentInfo Where ID =" + int.Parse(TXT1_studID.Text);
                SqlCommand comd = new SqlCommand(query, sqlconnect);
                SqlDataReader dr = comd.ExecuteReader();
                Update();
            }
            catch (Exception a)
            {
                Message.Show(a.Message);
            }
        
    }

        private void Update()
        {
            throw new NotImplementedException();
        }
    }



